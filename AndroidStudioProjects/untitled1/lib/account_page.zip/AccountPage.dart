import 'package:flutter/material.dart';
import 'package:untitled1/First.dart';
import 'package:untitled1/details1.dart';

//import 'account_page.dart';
class AccountPage extends StatefulWidget {
  const AccountPage({Key? key}) : super(key: key);

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
          /*  appBar: AppBar(
                title: Text('Account',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold)));*/
          body: Stack(children: [
        Container(
        height: double.infinity, //ارتفاع کل صفحه
          width: double.infinity, // عرض کل صفحه
          decoration: BoxDecoration(color: Colors.black12),
        ),
        Container(
            height:double.infinity, //ارتفاع کل صفحه
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 120),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  //?////////?????????????????????/
                  children: [
                    Text('Acount',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                        )),
                    Align(
                      alignment: Alignment.centerLeft,
                      child:Text('name:\n'
                          'Current credit:\n' ,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),

                    Align(
                      alignment: Alignment.centerRight,
                      child:Container(
                          height: 50,
                          width: 100,
                          //  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                          color: Colors.black26,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Colors.black38, // Background color
                            ),
                            child: const Text('Upgrade to special account' ,style: TextStyle(color: Colors.white70 , fontWeight: FontWeight.bold),),
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(builder:(context){
                                return LoginPage();
                              }));
                            },
                          )
                      ),
                    ),
                    Row(
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child:Container(
                              height: 50,
                              width: 100,
                              //  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                              color: Colors.black26,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: Colors.black38, // Background color
                                ),
                                child: const Text('Increase credit' ,style: TextStyle(color: Colors.white70 , fontWeight: FontWeight.bold),),
                                onPressed: () {
                                  Navigator.of(context).push(MaterialPageRoute(builder:(context){
                                    return LoginPage();
                                  }));
                                },
                              )
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child:Container(
                              height: 50,
                              width: 100,
                              //  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                              color: Colors.black26,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: Colors.black38, // Background color
                                ),
                                child: const Text('Upgrade to special account' ,style: TextStyle(color: Colors.white70 , fontWeight: FontWeight.bold),),
                                onPressed: () {
                                  Navigator.of(context).push(MaterialPageRoute(builder:(context){
                                    return LoginPage();
                                  }));
                                },
                              )
                          ),
                        ),
                      ],
                    ),

                //    SizedBox(
                //      height: 15.0,
            //            ),
                    Container(
                        height: 50,
                        // width: double.infinity,
                        //  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                        color: Colors.black26,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.black38, // Background color
                          ),
                          child: const Text('Leave' ,style: TextStyle(color: Colors.white70 , fontWeight: FontWeight.bold),),

                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(builder:(context){
                              return LoginPage();
                            }));
                          },
                        )
                    ),

                  ]),
            )),
        ])




        ));
  }
}
