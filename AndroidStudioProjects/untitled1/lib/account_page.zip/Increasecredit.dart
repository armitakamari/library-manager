import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Increasecredit extends StatelessWidget {
  const Increasecredit({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );

  }
}
