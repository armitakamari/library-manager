import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
//import 'package:easy_search/easy_search.dart';

class LibaryPage extends StatefulWidget {
  @override
  _LibaryPageState createState() => _LibaryPageState();
}

class _LibaryPageState extends State<LibaryPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  //static const historyLength = 5;
  Widget customSearchBar = const Text('Search' ,  style: TextStyle(color: Colors.black ,  fontSize: 25,
    fontWeight: FontWeight.bold,),);
//  get myCoolStrings => null;

  @override
  void initState() {
    _tabController = new TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  String searchValue = '';

  //final List<String> _suggestions = ['', 'Albania', 'Algeria', 'Australia', 'Brazil', 'German', 'Madagascar', 'Mozambique', 'Portugal', 'Zambia'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
            height: MediaQuery
                .of(context)
                .size
                .height / 3,

            color: Colors.black38,
            child: AppBar(
              backgroundColor:Colors.black38 ,
              title: const Text(
                'Search',
                style: TextStyle(color: Colors.white),
              ),
              actions: [
                IconButton(
                    onPressed: () {
                      showSearch(
                        context: context,
                        delegate: MySearchDelegate(),
                      );
                    },
                    icon: const Icon(Icons.search))
              ],
            ),
          ),
          TabBar(
            unselectedLabelColor: Colors.black12,
            labelColor: Colors.black,
            tabs: [
              Tab(
                //icon: Icon(Icons.edit_note_sharp),
                text: 'the most expensive',
              ),
              Tab(
                //icon: Icon(Icons.volume_up_outlined),
                text: 'The most faverate',
              )
            ],
            controller: _tabController,
            indicatorSize: TabBarIndicatorSize.tab,
          ),
          Expanded(
            child: TabBarView(
              children: [
                //  IudioBook(),
                // TextBook,
              ],
              controller: _tabController,

            ),
          ),
        ]),
      ),

      // color: Colors.black45,
      //  ),
      /*child: TabBar(
              unselectedLabelColor: Colors.black45,
              labelColor: Colors.black,
              tabs: [
                Tab(
                  text: 'High valubles',
                ),
                Tab(
                  text: 'Most favourite',
                )
              ],
              controller: _tabController,
              indicatorSize: TabBarIndicatorSize.tab,
            ),
            child: Expanded(
              child: TabBarView(
                children: [
                   // Text('tyu'),
                   // Text('Person'),
                ],
                controller: _tabController,
              ),
            ),*/
    );
  }
}

class MySearchDelegate extends SearchDelegate {
  List<String> searchReasults = [
    'ملت عشق',
    'من او',
    'صد جنگ بزرگ تاریخ',
    'یک قرن سکوت',
  ];

  get suggestions => null;

  get index => null;

  @override
  List<Widget>? buildActions(BuildContext context) {
    IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          if (query.isEmpty)
            close(context, null);
          else
            query = '';
        });
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        close(context, null);
      },
      icon: const Icon(Icons.arrow_back),
    );
    throw UnimplementedError();
  }

  @override
  Widget buildResults(BuildContext context) {
    // TODO: implement buildResults
    throw UnimplementedError();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    Iterable<String>segetion = searchReasults.where((String searchReasults) {
      final result = searchReasults.toLowerCase();
      final input = query.toLowerCase();
      return result.contains(input);
    }).toList();
    return ListView.builder(itemBuilder: (context, Index) {
      itemCount :
      var suggestion;
      suggestion.length;
      itemBuilder(context, Index) {
        final suggestion = suggestions[index];
        return ListTile(
          title: Text(suggestion),
          onTap: () {
            query = suggestion;
          },
        );
      }
    });
  }
}
